#include "mbed.h"
BusInOut leds(PA_0, PA_1, PA_9, PA_8, PA_4, PA_5, PA_6);
DigitalOut ADC_EN(PB_10);
DigitalIn Start_Key(PB_5);
DigitalIn Incresase_Key(PB_3);
DigitalOut Segment_sw(PB_4);
DigitalOut Heater(PB_6);
Ticker milisecond;

Serial pc(USBTX,USBRX);

int ms=0, a=0;
int aehiz0=1, tus_h0=0, tus_b0=0, sayac0=250;
int aehiz1=1, tus_h1=0, tus_b1=0, sayac1=250;
int set_temp=50, med_temp=5, show=0;
int digit1=0, digit2=0;

void give_pulse(){
    ms=1;
}

void key_detect(int Key, int &tus_h,int &tus_b,int &sayac, int &aehiz){    
        if(!Key){
            if(tus_b==1){
                if(tus_h==0){
                    sayac=sayac-aehiz;
                    if(sayac<0){
                        tus_h=1;
                        tus_b=1;
                        sayac=500;
                        aehiz++;
                    }                                 
                }
            }
            if(tus_b==0){
                if(tus_h==0){
                    sayac=sayac-5;
                    if(sayac<0){
                        tus_h=1;
                        tus_b=1;
                        sayac=500;
                    }                                 
                }
            }

        }
        else{
            tus_b=0;
            sayac=250;
            aehiz=1;
        }
}

void get_commands(){
    key_detect(Incresase_Key,tus_h0,tus_b0,sayac0,aehiz0);
    key_detect(Start_Key,tus_h1,tus_b1,sayac1,aehiz1);
    if(tus_h0){
        tus_h0=0;
        set_temp++;
        if(set_temp==100)
                set_temp=0;
    }
    show=tus_b1;
    tus_h1=0;
}

void take_measurments(){
    a++;
    if(a==10){
        a=0;
        ADC_EN=0;
        leds.input();
        wait(0.001);
        med_temp=(leds*100)/255;
        ADC_EN=1; 
    }
}

void display_digit(int digit){
        switch(digit)
        {
            case 0: {
            leds=0x3F;
                break;}
            case 1: {
            leds=0x06;
                break;}
            case 2: {
            leds=0x5B;
                break;}
            case 3: {
            leds=0x4F;
                break;}
            case 4: {
            leds=0x66;
                break;}
            case 5: {
            leds=0x6D;
                break;}
            case 6: {
            leds=0x7D;
                break;}
            case 7: {
            leds=0x07;
                break;}
            case 8: {
            leds=0x7F;
                break;}
            case 9: {
            leds=0x6F;
                break;}             
        }
}

void show_temp(){
    leds.output();
    if(show){
        digit1=med_temp%10;
        digit2=med_temp/10;
    }
    else{
        digit1=set_temp%10;
        digit2=set_temp/10;
    }
    Segment_sw=!Segment_sw;
    if(Segment_sw)
        display_digit(digit1);
    else
        display_digit(digit2);
}

void heat(){
    if(med_temp<set_temp)
        Heater=0;
    else
        Heater=1;
}

int main(){
    milisecond.attach(&give_pulse, 0.001); // her 1 ms geçtiğinde çalışır
    while (true) {
        if(ms) {
            ms=0;
            get_commands();
            take_measurments();
            pc.printf("%d   ",med_temp);
            show_temp();
            heat();
        }
    }
}