#include "mbed.h"

Ticker milisecond;
PwmOut PWMforNeg(PB_3);
Serial pc(SERIAL_TX,SERIAL_RX);

BusInOut Data(PA_0,PA_1,PA_9,PA_8,PA_4,PA_5,PA_6,PA_7);
BusOut RS_RW(PB_4,PB_5);
DigitalOut En(PB_10);
int BF=1;

void initialize_f(){
    Data.output();
    wait_ms(30);
    En=1;
    RS_RW=0;
    Data=0x38;  //8 bit, 2 lines, 5x7 
    En=0;
    wait_us(39);
    En=1;
    RS_RW=0;
    Data=0x0F;  //Diplay, Cursor,Blink
    En=0;
    wait_us(39);
    En=1;
    RS_RW=0;
    Data=0x06;  //Entry Mode, Increment cursor position, No display shift
    En=0;
    wait_us(39);
    En=1;
    RS_RW=0;
    Data=0x01;  //Clear
    En=0;
    wait_us(1640);
    
}

void Check_Busy(){
    Data.input();
    do{
        RS_RW=0;
        RS_RW=1;
        En=1;
        BF=(Data&0x08);
        En=0;
    }while(BF);  
    RS_RW=0;
    Data.output();
}

void Hello_World(){
    Check_Busy();  
    En=1;
    RS_RW=2;
    Data='H';  //H
    En=0;
    Check_Busy();
    En=1;
    RS_RW=2;
    Data=0x65;  //e
    En=0;
    Check_Busy();
    En=1;
    RS_RW=2;
    Data=0x6C;  //l
    En=0;
    Check_Busy();
    En=1;
    RS_RW=2;
    Data=0x6C;  //l
    En=0;
    Check_Busy();
    En=1;
    RS_RW=2;
    Data=0x6F;  //o
    En=0;
    Check_Busy();
    En=1;
    RS_RW=2;
    Data=0x20;  //Space
    En=0;
    Check_Busy();
    En=1;
    RS_RW=2;
    Data=0x57;  //W
    En=0;
    Check_Busy();
    En=1;
    RS_RW=2;
    Data=0x6F;  //o
    En=0;
    Check_Busy();
    En=1;
    RS_RW=2;
    Data=0x72;  //r
    En=0;
    Check_Busy();
    En=1;
    RS_RW=2;
    Data=0x6C;  //l
    En=0;
    Check_Busy();
    En=1;
    RS_RW=2;
    Data=0x64;  //d
    En=0;
    Check_Busy();
    En=1;
    RS_RW=2;
    Data=0x21;  //!
    En=0;
    Check_Busy();
}

void Send_Char(char character){
    Check_Busy();
    En=1;
    RS_RW=2;
    Data=character; 
    En=0;
}

void Send_Cmd(int command){
    Check_Busy();
    En=1;
    RS_RW=0;
    Data=command;
    En=0;
    wait_us(2000);
}


int main(){
    //PWMforNeg.period_us(10);      
    //PWMforNeg.pulsewidth_us(5);
 
    initialize_f();
    Hello_World();
    wait(1);
    Send_Cmd(1);
    Send_Char('A');
    Send_Char('D');
    Send_Char('E');
    Send_Char('M');
    wait(1);
    Send_Cmd(0x40);
    Send_Char(0);
    Send_Char(10);
    Send_Char(31);
    Send_Char(31);
    Send_Char(14);
    Send_Char(4);
    Send_Char(0);
    Send_Cmd(1);
    Send_Char(0);
    Send_Cmd(1);
    Send_Char(0);
    
    
    
    
}