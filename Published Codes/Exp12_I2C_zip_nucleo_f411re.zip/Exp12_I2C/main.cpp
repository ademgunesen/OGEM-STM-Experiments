#include "mbed.h"
Serial pc(SERIAL_TX,SERIAL_RX);
I2C i2c(I2C_SDA , I2C_SCL ); 

const int addr7bit = 0xA2;      // 7 bit I2C address, 1 bit 0
char reg_add[1];
char time_data[4];
char values[3];
char setting[4];
int i=0;
int seconds=0,minutes=0,hours=0,years=0;

void save_data(){
    setting[0]=0x10;
    setting[1]=0x09;
    setting[2]=0x1F;
    setting[3]=0x09;
    i2c.write(addr7bit, setting, 4);
    }
void read_data(){
    i2c.write(addr7bit, setting, 1);
    i2c.read( addr7bit, values, 3);
}

void get_time(){
    reg_add[0]=0x02;
    i2c.write(addr7bit, reg_add, 1);
    i2c.read( addr7bit, time_data, 4);
    }

void calculate_time(){
    for(i=0;i<3;i++){
        time_data[i]  =  ((time_data[i] & 0xF0) >> 4)*10 + (time_data[i] & 0x0F);}
    seconds=time_data[0];
    minutes=time_data[1];
    hours=time_data[2];
    years=time_data[3];
    }
    
int main() {
    save_data();
    read_data();
    while (1) {
        
        get_time();
        calculate_time();
       pc.printf("%d\t%d\t%d\t%d\t\n",years,hours,minutes,seconds);
        wait(1);
        
        //pc.printf("%d\t%d\t%d\t\n", values[0],values[1],values[2]);
        //wait(1);
        
 

    }
}