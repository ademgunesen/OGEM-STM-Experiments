#include "mbed.h"
#include "time.h"
BusOut  USTRX(PB_5,PB_10,PB_4);
InterruptIn USRCX(PC_0);

BusInOut Data(PA_0,PA_1,PA_9,PA_8,PA_4,PA_5,PA_6,PA_7);
BusOut RS_RW(PB_0,PB_6);
DigitalOut En(PB_3);
int BF=1;

Serial pc(SERIAL_TX,SERIAL_RX);

Timer t;
int ftime=100,i=0,echo=0;
int distance=1234,dec_1=0,dec_10=0,dec_100=0,dec_1000=0;

void Send_Sound(){
    t.reset();
    USTRX=0x0;
    wait_ms(400);
    for(i=0;i<8;i++){
        USTRX=0x4;
        wait_us(10);
        USTRX=0x2;
        wait_us(10);
    }
    USTRX=0x1;
}

void heard(){
    t.stop();
    ftime=t.read_us();
}

void Measure_Time(){
    t.start();
    wait_ms(70);
    t.stop();
}

void Calculate_Distance(){
    distance=(ftime*344)/2000;
    dec_1=distance%10;
    dec_10=(distance/10)%10;
    dec_100=(distance/100)%10;
    dec_1000=(distance/1000)%10;
}


void Initialise_LCD(){
    Data.output();
    wait_ms(30);
    En=1;
    RS_RW=0;
    Data=0x38;  //8 bit, 2 lines, 5x7 
    En=0;
    wait_us(39);
    En=1;
    RS_RW=0;
    Data=0x0C;  //Diplay, Cursor,Blink
    En=0;
    wait_us(39);
    En=1;
    RS_RW=0;
    Data=0x06;  //Entry Mode, Increment cursor position, No display shift
    En=0;
    wait_us(39);
    En=1;
    RS_RW=0;
    Data=0x01;  //Clear
    En=0;
    wait_us(1640);
    
    
}

void Check_Busy(){
    Data.input();
    do{
        RS_RW=0;
        RS_RW=1;
        En=1;
        BF=(Data&0x08);
        En=0;
    }while(BF);  
    RS_RW=0;
    Data.output();
}

void Send_Char(char character){
    Check_Busy();
    En=1;
    RS_RW=2;
    Data=character; 
    En=0;
}

void Send_Cmd(int command){
    Check_Busy();
    En=1;
    RS_RW=0;
    Data=command;
    En=0;
    wait_us(2000);
}

void Display_LCD(){
    Send_Cmd(1);
    Send_Char('D');
    Send_Char('i');
    Send_Char('s');
    Send_Char('t');
    Send_Char('a');
    Send_Char('n');
    Send_Char('c');
    Send_Char('e');
    Send_Char(':');
    Send_Char(' ');
    Send_Char(48+dec_1000);
    Send_Char(48+dec_100);
    Send_Char(48+dec_10);
    Send_Char(48+dec_1);
    Send_Char('m');
    Send_Char('m');
    Send_Cmd(0xC0);
    Send_Char('a');
    Send_Char('s');
    Send_Char(' ');
    Send_Char('m');
    Send_Char('e');
    Send_Char('a');
    Send_Char('s');
    Send_Char('u');
    Send_Char('r');
    Send_Char('e');
    Send_Char('d');
    
}

void Display_Dist(){
    Send_Cmd(128 + 10);
    Send_Char(48+dec_1000);
    Send_Char(48+dec_100);
    Send_Char(48+dec_10);
    Send_Char(48+dec_1);
}


int main(){
    USRCX.fall(&heard);
    Initialise_LCD();
    Display_LCD();
    while(1){
        Send_Sound();
        Measure_Time();
        Calculate_Distance();
        Display_Dist();
    }
    
}