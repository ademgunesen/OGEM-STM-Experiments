#include "mbed.h"
BusOut leds(PA_0, PA_1, PA_9, PA_8, PA_4, PA_5, PA_6);
DigitalIn kat3(PB_3);
DigitalIn kat2(PB_5);
DigitalIn kat1(PB_4);
DigitalIn kat0(PB_10);
DigitalOut down(PB_6);
DigitalOut up(PA_7);

Ticker milisecond;

int durum=0,bas=0;
int tus_h0=0,tus_b0=0,sayac0=10,tus_h1=0,tus_b1=0,sayac1=10,tus_h2=0,tus_b2=0,sayac2=10,tus_h3=0,tus_b3=0,sayac3=10;
int degerlendir=0;
int ms=0, sayacup=0,sayacdown=0;

void give_pulse() {
    ms=1;
}

void key_detect(int Key, int &tus_h,int &tus_b,int &sayac)
{
    if(!Key) {
        if(tus_b==0) {
            if(tus_h==0) {
                sayac--;
                if(sayac<0) {
                    tus_h=1;
                    tus_b=1;
                    sayac=10;
                }
            }
        }


    } else {
        tus_b=0;
        sayac=10;
    }
}

void go_up(){
    up=1;
    down=0;
    sayacup++;
    if (sayacup==1000){
        sayacup=0;
        durum++;
    }
}
void go_down(){
    up=0;
    down=1;
    sayacdown++;
    if (sayacdown==1000){
        sayacdown=0;
        durum--;
    }
}

int main() {
    milisecond.attach(&give_pulse, 0.001);
    while (true) {
        if(ms){                            
            ms=0;
            key_detect(kat0,tus_h0,tus_b0,sayac0);
            key_detect(kat1,tus_h1,tus_b1,sayac1);
            key_detect(kat2,tus_h2,tus_b2,sayac2);
            key_detect(kat3,tus_h3,tus_b3,sayac3);
            
            
            if(tus_h0==1){
                bas=0;
                tus_h0=0;
            }
            if(tus_h1==1){
                bas=2;
                tus_h1=0;
            }
            if(tus_h2==1){
                bas=4;
                tus_h2=0;
            }
            if(tus_h3==1){
                bas=6;
                tus_h3=0;
            }
            
                if(bas==durum){

                    down=1;
                    up=1;
                }
                else if(bas>durum){
                    go_up();
                }
                else{
                    go_down();
                }
            
            
        leds=0xFF;
        leds[durum]=0;
        }
    }
}