#include "mbed.h"

Ticker milisecond;
int ms=0,step=0;
int direction=0, start=0, mot_say=0;
int tus_b=0, tus_h=0, sayac=5, in=0;
int del_t=50;
int digit1=0, digit2=0, dig_switch=0;

BusOut ledmot(PA_0, PA_1, PA_9, PA_8);
BusInOut ledkey(PA_4, PA_5, PA_6, PA_7);
DigitalOut clockreg(PB_5);
BusOut transistors(PB_10,PB_4);
DigitalOut Key_EN(PB_3);

void give_pulse(){
    ms=1;
}

void motor(){
    transistors=0x0;
    mot_say++;
    if(mot_say>del_t) {
        mot_say=0;
        if(direction){
            step++;
            if(step==4)
                step=0;
        }
        else{
            step--;
            if(step==-1)
                step=3;
        }
        switch (step) {
            case 0: {
                ledmot=0xA;
                break;
            }
            case 1: {
                ledmot=0x6;
                break;
            }
            case 2: {
                ledmot=0x5;
                break;
            }
            case 3: {
                ledmot=0x9;
                break;
            }
        }
        clockreg=1;
        clockreg=0;
    }
}

void key_detect(int Key, int &tus_h,int &tus_b,int &sayac){

    if(Key) {
        if(tus_b==0) {
            if(tus_h==0) {
                sayac--;
                if(sayac<0) {
                    tus_h=1;
                    tus_b=1;
                    sayac=5;
                }
            }
        }


    } else {
        tus_b=0;
        sayac=5;
    }
}

void get_parameters(){
    ledkey.input();
    ledkey.mode(PullDown);
    key_detect(ledkey,tus_h,tus_b,sayac);
    if(tus_h==1) {
        tus_h=0;
        in=ledkey;
        switch(in) {
            case 1: {
                del_t++;
                break;
            }
            case 8: {
                start=!start;
                break;
            }
            case 4: {
                del_t+=10;
                break;
            }
            case 2: {
                direction=!direction;
                break;
            }
        }
    }
}

void display_digit(int digit){
    switch(digit) {
        case 0: {
            ledkey=0x3;
            ledmot=0xF;
            break;
        }
        case 1: {
            ledkey=0x0;
            ledmot=0x6;
            break;
        }
        case 2: {
            ledkey=0x5;
            ledmot=0xB;
            break;
        }
        case 3: {
            ledkey=0x4;
            ledmot=0xF;
            break;
        }
        case 4: {
            ledkey=0x6;
            ledmot=0x6;
            break;
        }
        case 5: {
            ledkey=0x6;
            ledmot=0xD;
            break;
        }
        case 6: {
            ledkey=0x7;
            ledmot=0xD;
            break;
        }
        case 7: {
            ledkey=0x0;
            ledmot=0x7;
            break;
        }
        case 8: {
            ledkey=0x7;
            ledmot=0xF;
            break;
        }
        case 9: {
            ledkey=0x6;
            ledmot=0xF;
            break;
        }
    }
}

void scan_digits(){
    ledkey.output();
    digit1=del_t%10;
    digit2=del_t/10;
    if(del_t>100)
        del_t=0;
    if(dig_switch){
        transistors=0x2;
        display_digit(digit1);
    }
    else{
        transistors=0x1;
        display_digit(digit2);
    }
}

int main()
{
    milisecond.attach(&give_pulse, 0.001); // her 1 ms geçtiğinde çalışır
    transistors=0;
    Key_EN=1;
    while (true) {
        Key_EN=1;
        if(ms) {
            ms=0;
            dig_switch=!dig_switch;
            get_parameters();
            if(start)
                motor();
            scan_digits();
        }
    }
}